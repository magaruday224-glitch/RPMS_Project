from util.db_connection import Database
from util.logger import logger
class PlacementService:
    def record(self,application_id,company_id,designation,package_lpa,joining_date,joining_status="JOINED"):
        pid=Database.execute("INSERT INTO placements(application_id,company_id,designation,final_package_lpa,actual_joining_date,joining_status) VALUES(%s,%s,%s,%s,%s,%s)",(application_id,company_id,designation,package_lpa,joining_date,joining_status)); logger.info("Placement recorded: %s",pid); return pid
    def all(self): return Database.fetch_all("SELECT p.*,c.name company_name,ca.name candidate_name FROM placements p JOIN companies c ON c.company_id=p.company_id JOIN applications a ON a.application_id=p.application_id JOIN candidates ca ON ca.candidate_id=a.candidate_id ORDER BY placement_id DESC")
