class Company:
    def __init__(self, name, industry="", contact_person="", email="", phone="", location="", website=""):
        self.name=name; self.industry=industry; self.contact_person=contact_person; self.email=email
        self.phone=phone; self.location=location; self.website=website
