from dao.job_dao import JobDAO
from util.validators import percentage, non_negative_int, required
from util.logger import logger
class JobService:
    def __init__(self): self.dao=JobDAO()
    def add(self, data):
        data["title"]=required(data["title"],"Job title"); data["technology"]=required(data["technology"],"Technology")
        data["openings"]=non_negative_int(data["openings"],"Openings"); data["min_percentage"]=percentage(data["min_percentage"])
        data["max_backlogs"]=non_negative_int(data["max_backlogs"],"Maximum backlogs")
        from model.job import Job
        jid=self.dao.add(Job(**data)); logger.info("Job created: %s",jid); return jid
    def update(self, job_id, values): self.dao.update(job_id, values)
    def search(self, keyword): return self.dao.search(keyword)
    def all(self): return self.dao.all()
    def open_jobs(self): return self.dao.open_jobs()
    def get(self, jid): return self.dao.get(jid)
    def close(self, jid): self.dao.close(jid)
