def percentage(value):
    value=float(value)
    if not 0 <= value <= 100: raise ValueError("Percentage must be between 0 and 100.")
    return value

def non_negative_int(value, label="Value"):
    value=int(value)
    if value < 0: raise ValueError(f"{label} cannot be negative.")
    return value

def required(value, label):
    value=str(value).strip()
    if not value: raise ValueError(f"{label} is required.")
    return value
