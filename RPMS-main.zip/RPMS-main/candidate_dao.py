from util.db_connection import Database
class CandidateDAO:
    def add(self, c):
        return Database.execute("INSERT INTO candidates(name,email,mobile,qualification,percentage,passing_year,technology,skills,backlogs) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)", (c.name,c.email,c.mobile,c.qualification,c.percentage,c.passing_year,c.technology,c.skills,c.backlogs))
    def update(self, candidate_id, c):
        Database.execute("UPDATE candidates SET name=%s,email=%s,mobile=%s,qualification=%s,percentage=%s,passing_year=%s,technology=%s,skills=%s,backlogs=%s WHERE candidate_id=%s", (c.name,c.email,c.mobile,c.qualification,c.percentage,c.passing_year,c.technology,c.skills,c.backlogs,candidate_id))
    def get(self, candidate_id): return Database.fetch_one("SELECT * FROM candidates WHERE candidate_id=%s",(candidate_id,))
    def search(self, keyword): return Database.fetch_all("SELECT * FROM candidates WHERE name LIKE %s OR email LIKE %s OR technology LIKE %s",(f"%{keyword}%",)*3)
    def all(self): return Database.fetch_all("SELECT * FROM candidates ORDER BY candidate_id DESC")
    def deactivate(self, candidate_id): Database.execute("UPDATE candidates SET active=0 WHERE candidate_id=%s",(candidate_id,))
