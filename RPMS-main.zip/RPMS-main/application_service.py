from dao.candidate_dao import CandidateDAO
from dao.job_dao import JobDAO
from dao.application_dao import ApplicationDAO
from service.eligibility_service import EligibilityService
from exception.custom_exceptions import DuplicateApplicationError, CandidateNotEligibleError
from util.logger import logger
class ApplicationService:
    def __init__(self): self.candidates=CandidateDAO(); self.jobs=JobDAO(); self.apps=ApplicationDAO(); self.eligibility=EligibilityService()
    def apply(self,cid,jid):
        c=self.candidates.get(cid); j=self.jobs.get(jid)
        result=self.eligibility.check(c,j)
        if not result["eligible"]: raise CandidateNotEligibleError("; ".join(result["reasons"]))
        if self.apps.exists(cid,jid): raise DuplicateApplicationError("Candidate has already applied for this job.")
        aid=self.apps.add(cid,jid); logger.info("Application submitted: %s",aid); return aid
    def all(self): return self.apps.all()
    def status(self,aid,status):
        allowed={"APPLIED":{"SHORTLISTED","REJECTED"},"SHORTLISTED":{"INTERVIEW","REJECTED"},"INTERVIEW":{"SELECTED","REJECTED"},"SELECTED":{"OFFERED","REJECTED"},"OFFERED":{"JOINED","REJECTED"},"JOINED":set(),"REJECTED":set()}
        current=next((a for a in self.apps.all() if a["application_id"]==aid),None)
        if not current: raise ValueError("Application ID not found")
        if status not in allowed.get(current["status"],set()): raise ValueError(f"Invalid transition {current['status']} -> {status}")
        self.apps.update_status(aid,status)
