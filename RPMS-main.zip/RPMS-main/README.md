# Recruitment & Placement Management System (RPMS)

Python + MySQL console application with HTML/CSS UI prototypes, based on the supplied project abstract and technical specification.

## Modules
Candidate management, company management, job management, eligibility engine, application workflow, interviews/feedback, offers, placements, reports, logging.

## Requirements
- Python 3.9 or newer
- MySQL 8.x (or compatible MySQL server)

## Setup
1. Install MySQL and start the server.
2. Open MySQL Workbench or a MySQL terminal and run `sql/database.sql`.
3. Create a virtual environment (recommended): `python -m venv .venv`
4. Activate: Windows `.venv\Scripts\activate`; macOS/Linux `source .venv/bin/activate`
5. Install: `pip install -r requirements.txt`
6. Copy `.env.example` to `.env`, then set DB_PASSWORD and any other values.
7. Run from the project root: `python main.py`

## Menu
The console menu covers candidate/company/job CRUD basics, applications, status transitions, interview scheduling/feedback, offers, placements, and reports.

## Eligibility rules
Candidate must be active, job open, before deadline, not already applied, meet minimum percentage and passing-year requirement (if set), backlog maximum, and have the required technology in the candidate technology or skills fields.

## Application status flow
APPLIED -> SHORTLISTED -> INTERVIEW -> SELECTED -> OFFERED -> JOINED. REJECTED is available from active stages. Invalid direct transitions are blocked.

## UI prototype disclaimer
The HTML/CSS pages are standalone UI mockups and are **not connected** to the Python/MySQL backend, as specified in the abstract.
## Security and limitations
Parameterized SQL is used for database operations. This is a student project console application; production deployment would need authentication, authorization, secure secrets management, stronger auditing, and additional validation.
