# RPMS Test Cases

| ID | Test | Expected result |
|---|---|---|
| TC01 | Register candidate with valid fields | Candidate saved; unique ID returned |
| TC02 | Duplicate candidate email | Database rejects duplicate |
| TC03 | Duplicate mobile | Database rejects duplicate |
| TC04 | Percentage below 0 or above 100 | Validation error |
| TC05 | Negative backlog count | Validation error |
| TC06 | Create company | Company saved |
| TC07 | Create job with valid company | Job saved as OPEN |
| TC08 | Apply with inactive candidate | Not eligible with reason |
| TC09 | Apply to closed job | Not eligible with reason |
| TC10 | Apply after deadline | Not eligible with reason |
| TC11 | Percentage below requirement | Not eligible with reason |
| TC12 | Passing year mismatch | Not eligible with reason |
| TC13 | Backlogs exceed limit | Not eligible with reason |
| TC14 | Candidate missing required technology | Not eligible with reason |
| TC15 | Duplicate application | Duplicate blocked |
| TC16 | APPLIED -> JOINED | Invalid transition blocked |
| TC17 | Valid status progression | Status update succeeds |
| TC18 | Schedule interview | Interview record saved |
| TC19 | Save interview feedback | Ratings and result saved |
| TC20 | Create offer and placement | Records saved |
| TC21 | Generate reports | Report rows displayed |
