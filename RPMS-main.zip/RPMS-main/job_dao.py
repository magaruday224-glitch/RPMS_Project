from util.db_connection import Database
class JobDAO:
    def add(self, j): return Database.execute("INSERT INTO jobs(company_id,title,technology,openings,location,package_lpa,min_percentage,passing_year,max_backlogs,deadline,description) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(j.company_id,j.title,j.technology,j.openings,j.location,j.package_lpa,j.min_percentage,j.passing_year,j.max_backlogs,j.deadline,j.description))
    def all(self): return Database.fetch_all("SELECT j.*,c.name company_name FROM jobs j JOIN companies c ON c.company_id=j.company_id ORDER BY j.job_id DESC")
    def open_jobs(self): return Database.fetch_all("SELECT j.*,c.name company_name FROM jobs j JOIN companies c ON c.company_id=j.company_id WHERE j.status='OPEN' ORDER BY j.job_id DESC")
    def get(self, job_id): return Database.fetch_one("SELECT j.*,c.name company_name FROM jobs j JOIN companies c ON c.company_id=j.company_id WHERE j.job_id=%s",(job_id,))
    def update(self, job_id, values):
        Database.execute("UPDATE jobs SET title=%s,technology=%s,openings=%s,location=%s,package_lpa=%s,min_percentage=%s,passing_year=%s,max_backlogs=%s,deadline=%s,description=%s WHERE job_id=%s", values)
    def search(self, keyword): return Database.fetch_all("SELECT j.*,c.name company_name FROM jobs j JOIN companies c ON c.company_id=j.company_id WHERE j.title LIKE %s OR j.technology LIKE %s OR c.name LIKE %s",(f"%{keyword}%",)*3)
    def close(self, job_id): Database.execute("UPDATE jobs SET status='CLOSED' WHERE job_id=%s",(job_id,))
