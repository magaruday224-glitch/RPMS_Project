from datetime import date
from service.candidate_service import CandidateService
from service.job_service import JobService
from service.application_service import ApplicationService
from service.interview_service import InterviewService
from service.offer_service import OfferService
from service.placement_service import PlacementService
from service.report_service import ReportService
from dao.company_dao import CompanyDAO
from dao.candidate_dao import CandidateDAO
from dao.job_dao import JobDAO
from util.db_connection import Database

cs=CandidateService(); js=JobService(); aps=ApplicationService(); ins=InterviewService(); ofs=OfferService(); pls=PlacementService(); rs=ReportService(); co=CompanyDAO()
def ask(label, default=None):
    value=input(f"{label}"+(f" [{default}]" if default is not None else "")+": ").strip()
    return value if value else default
def show(rows):
    if not rows: print("No records found."); return
    for row in rows: print(" | ".join(f"{k}={v}" for k,v in row.items()))
def add_candidate():
    data={"name":ask("Full name"),"email":ask("Email"),"mobile":ask("Mobile"),"qualification":ask("Qualification"),"percentage":ask("Percentage"),"passing_year":ask("Passing year"),"technology":ask("Primary technology"),"skills":ask("Skills (comma separated)",""),"backlogs":ask("Backlogs","0")}
    print("Candidate created with ID:",cs.add(data))
def update_candidate():
    show(cs.all()); cid=int(ask("Candidate ID to update")); old=cs.dao.get(cid)
    if not old: raise ValueError("Candidate not found")
    data={"name":ask("Full name",old["name"]),"email":ask("Email",old["email"]),"mobile":ask("Mobile",old["mobile"]),"qualification":ask("Qualification",old["qualification"]),"percentage":ask("Percentage",str(old["percentage"])),"passing_year":ask("Passing year",str(old["passing_year"])),"technology":ask("Primary technology",old["technology"]),"skills":ask("Skills",old.get("skills") or ""),"backlogs":ask("Backlogs",str(old["backlogs"]))}
    cs.update(cid,data); print("Candidate updated.")
def add_company():
    vals=(ask("Company name"),ask("Industry",""),ask("Contact person",""),ask("Email",""),ask("Phone",""),ask("Location",""),ask("Website",""))
    print("Company created ID:",co.add(vals))
def add_job():
    companies=co.all(); show(companies)
    data={"company_id":ask("Company ID"),"title":ask("Job title"),"technology":ask("Required technology/skill"),"openings":ask("Openings","1"),"location":ask("Location",""),"package_lpa":ask("Package (LPA)","0"),"min_percentage":ask("Minimum percentage","0"),"passing_year":ask("Required passing year (blank = any)",None),"max_backlogs":ask("Maximum backlogs","0"),"deadline":ask("Deadline YYYY-MM-DD (blank = none)",None),"description":ask("Description","" )}
    if data["passing_year"]=="": data["passing_year"]=None
    if data["deadline"]=="": data["deadline"]=None
    print("Job created ID:",js.add(data))
def update_job():
    show(js.all()); jid=int(ask("Job ID to update")); old=js.get(jid)
    if not old: raise ValueError("Job not found")
    vals=(ask("Title",old["title"]),ask("Technology",old["technology"]),ask("Openings",str(old["openings"])),ask("Location",old.get("location") or ""),ask("Package LPA",str(old["package_lpa"] or 0)),ask("Minimum percentage",str(old["min_percentage"])),ask("Passing year (blank = any)",str(old["passing_year"] or "")),ask("Maximum backlogs",str(old["max_backlogs"])),ask("Deadline YYYY-MM-DD (blank = none)",str(old["deadline"] or "")),ask("Description",old.get("description") or ""),jid)
    vals=list(vals); vals[6]=vals[6] or None; vals[8]=vals[8] or None; js.update(jid,tuple(vals)); print("Job updated.")
def apply():
    show(js.open_jobs()); cid=ask("Candidate ID"); jid=ask("Job ID"); print("Application ID:",aps.apply(cid,jid))
def update_app():
    show(aps.all()); aid=ask("Application ID"); status=ask("New status (SHORTLISTED/INTERVIEW/SELECTED/OFFERED/JOINED/REJECTED)").upper(); aps.status(int(aid),status); print("Status updated")
def add_interview():
    show(aps.all()); aid=ask("Application ID"); roundn=ask("Round name"); dt=ask("Date/time YYYY-MM-DD HH:MM:SS"); mode=ask("Mode ONLINE/OFFLINE/PHONE").upper(); interviewer=ask("Interviewer","" ); notes=ask("Notes","" ); print("Interview ID:",ins.add(aid,roundn,dt,mode,interviewer,notes))
def interview_feedback():
    show(ins.all()); iid=ask("Interview ID"); tech=ask("Technical rating (0-10)"); comm=ask("Communication rating (0-10)"); remarks=ask("Remarks","" ); result=ask("Result PASS/FAIL/PENDING","PENDING").upper(); ins.feedback(iid,tech,comm,remarks,result); print("Feedback saved")
def add_offer():
    show(aps.all()); aid=ask("Application ID"); des=ask("Designation"); package=ask("Package LPA"); od=ask("Offer date YYYY-MM-DD",str(date.today())); jd=ask("Joining date YYYY-MM-DD"); status=ask("Status PENDING/ACCEPTED/DECLINED/JOINED","PENDING").upper(); print("Offer ID:",ofs.create(aid,des,package,od,jd,status))
def add_placement():
    show(aps.all()); aid=ask("Application ID"); cid=ask("Company ID"); des=ask("Designation"); pkg=ask("Final package LPA"); join=ask("Actual joining date YYYY-MM-DD"); status=ask("Joining status JOINED/PENDING/NOT_JOINED","JOINED").upper(); print("Placement ID:",pls.record(aid,cid,des,pkg,join,status))
def reports():
    print("1 Candidates by technology  2 Open jobs  3 Applications by status  4 Company placements  5 Placed/unplaced")
    choice=ask("Report"); options={"1":rs.candidates_by_technology,"2":rs.open_jobs,"3":rs.applications_by_status,"4":rs.company_placements,"5":rs.placed_unplaced}; show(options[choice]())
def menu():
    print("""
========== RECRUITMENT & PLACEMENT MANAGEMENT SYSTEM ==========
1 Candidate - Add   2 Candidate - View   3 Candidate - Search   4 Candidate - Deactivate
5 Company - Add   6 Company - View   7 Job - Add   8 Jobs - View Open   9 Jobs - View All   10 Job - Close
11 Apply for Job   12 Applications - View   13 Application - Update Status
14 Interview - Schedule   15 Interview - View   16 Interview - Feedback
17 Offer - Create   18 Offers - View   19 Placement - Record   20 Placements - View
21 Reports   22 Candidate Update   23 Job Update   24 Job Search   0 Exit""")
def main():
    try:
        Database.connect().close(); print("Database connected successfully.")
    except Exception as e:
        print("Database connection failed:",e); print("Check MySQL, database.sql and .env settings."); return
    actions={"1":add_candidate,"2":lambda:show(cs.all()),"3":lambda:show(cs.search(ask("Search name/email/technology"))),"4":lambda:cs.deactivate(ask("Candidate ID")),"5":add_company,"6":lambda:show(co.all()),"7":add_job,"8":lambda:show(js.open_jobs()),"9":lambda:show(js.all()),"10":lambda:js.close(ask("Job ID")),"11":apply,"12":lambda:show(aps.all()),"13":update_app,"14":add_interview,"15":lambda:show(ins.all()),"16":interview_feedback,"17":add_offer,"18":lambda:show(ofs.all()),"19":add_placement,"20":lambda:show(pls.all()),"21":reports,"22":update_candidate,"23":update_job,"24":lambda:show(js.dao.search(ask("Search job title/company/technology")))}
    while True:
        menu(); choice=ask("Choose option")
        if choice=="0": print("Thank you for using RPMS."); break
        try:
            if choice in actions: actions[choice]()
            else: print("Invalid menu choice.")
        except Exception as e: print("ERROR:",e)
if __name__=="__main__": main()
